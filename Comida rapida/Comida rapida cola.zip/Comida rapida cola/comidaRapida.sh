clear
gcc cliente.c ../Table/table.c -o cliente -Wall
gcc cocinero.c ../Table/table.c -o cocinero -Wall
gcc camarero.c ../Table/table.c -o camarero -Wall
gcc limpiador.c ../Table/table.c -o limpiador -Wall
gcc comidaRapidaCola.c ../Table/table.c -o comidaRapidaCola -Wall
./comidaRapidaCola
